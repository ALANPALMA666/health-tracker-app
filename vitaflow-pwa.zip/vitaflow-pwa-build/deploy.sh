#!/bin/bash
echo "🚀 Starting VitaFlow PWA..."
if command -v python3 &> /dev/null; then
    python3 -m http.server 8080
elif command -v python &> /dev/null; then
    python -m SimpleHTTPServer 8080
else
    echo "❌ Python not found. Upload files to web server."
fi
